# Arithmetic Operators(Questions 1 - 10)
#Q1
a = 15
b = 4
print(a + b)
print(a - b)
print(a * b)
print(a / b)
print(a // b)
print(a % b)
print(a ** b)

##Q3
y = 5 * 3
z = 2 * 4
print(y)#15
print(z)#8


##Q4
b = 3
c = 10
d =(b%c)
print(d)

#Q5
length = 12
width = 14
aria = length * width
print(aria)

#Q6
print(10 + 5 * 2)
print((10 + 5) * 2)

#Q7
print(9%2)
print(10 % 2)
print(11 % 2)

#Q8
print(100//7) #remainder(14)
print(100%7)

#Q9
base = int(input("enter base: "))
count = int(input("enter count: "))
exponent = (base**count)
print(exponent)#enter base 10 and count 3,exponent is 1000

#Q10
a = (-5)*2
print(a)#a = -10
b = -5 * 2
print(b)#a = -10

#Assignment Operators (Questions 11-20)
#Q11
x =10
x +=5
x -=3
x *=2
print(x) # x = 24

#Q12
a = 20
a //= 3
a %= 4
print(a) # a = 2

#Q13
y *= 3

#Q14.
score = 50
score += 10
score *= 10
score -= 10
print(score)#590

# Q15
n = 7
n *= 5
n /= 2
print(n)#17.5

# Q16
z =100
z **= 2
z //= 2
print(z)#5000

#Q17
p = 5
p +=p
print(p)#10

#Q18
number = int(input("enter number: "))
number +=10
print(number)#12 +=10 =22

# Q19
a = 10
b = 3
a *= b
a +=5
print(a) #35

#Q20
x = 5
y = 10
z = 15
x += y
z *= 2
print(x)#15
print(z)#30

#Comparison Operators (Questions 21-30)
# Q21
h1 = 10
h2 = 10
print(h1 == h2) #True

h3 = 5
print(h3 != h1) #True

h4 = 7
h5 = 3
print(h4 > h3)#True

n1 = 4
n2 = 8
print(n1 < n2)#True

n3 = 5
n4 = 5
print(n3 >= n4)#True

n5 = 6
n6 = 10
print(n5 <= n6)#True

# Q22
a = 15
b = 20
print(a > b)#False
print(a < b)#True
print(a <= b)#True

#Q23
age = 18
print("22 age is less than 20",age < 20) #True

# Q24
print(5 =="5")# ek 5 int main ha or doosra 5 str main ha is lia false ha

#Q25
x = 10
y =10.0
print(x == y)# x or y equal hee ,10.0 zero ky jga or digit nh ha

#26
u1 = int(input("enter first number: "))
u2 = int(input("enter second number: "))
print(u1 > u2) #u1 = 10,u2 = 5 (True)

#27
result = (10 + 5) > (3 * 4)
print(result) #True

#28
a = 7
b = 7
print(a == b)#True
print(a >= b)#True